#pragma once

bool SteamCheckPassive(void);
bool SteamLaunch(void);
